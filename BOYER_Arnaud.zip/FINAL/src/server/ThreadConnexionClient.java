package server;

import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import connexion.Connexion;

import queries.Queries;
public class ThreadConnexionClient implements Runnable {
	private Socket m_socket;
	private Server m_server1;
	private String m_nom;
	
	public ThreadConnexionClient(Socket socket, Server server1) {
		m_socket = socket;
		m_server1 = server1;
		System.out.println("Systeme de connexion client crée");
	}
	
	public void run() {
		m_nom = Thread.currentThread().getName();
		System.out.println(Thread.currentThread());
		String aide = "Commande possibles : ";
		// essai
		try {
			// création des mécanismes I/O
			// boucle infini
			// demande client
			// Mise en place du mécanisme de lecture
			BufferedReader sin = new BufferedReader(new InputStreamReader(m_socket.getInputStream()));

			// Mise en place du mécanisme d'écriture
			PrintWriter sout = new PrintWriter(m_socket.getOutputStream(), true);
			//sout.println("Commandes possibles : Tapez Carte, Quit ou Aide");
			Connexion con = new Connexion();
			while(true) {
				sout.println("Tapez Aide Recherche ou Quit ");
				String message = sin.readLine();
				if(message.equals("Aide")) {
					sout.println("Tapez Recherche ou Quit ");
				} else if(message.equals("Recherche")){
					sout.println("AvAnnee ApAnnee Annee Prenom Tout Quit");
					String recherche = sin.readLine();
					if(recherche.equals("AvAnnee")) {
						sout.println("Entrez une année ");
						String annee = sin.readLine();
						Queries quer = new Queries();
						sout.println(quer.AvAnnee(annee));
					} else if(recherche.equals("Tout")) {
						Queries quer = new Queries();
						sout.println(quer.tout());
					} else if(recherche.equals("ApAnnee")) {
						sout.println("Entrez une année ");
						String annee = sin.readLine();
						Queries quer = new Queries();
						quer.ApAnnee(annee);
					} else if(recherche.equals("Annee")) {
						sout.println("Entrez une année ");
						String annee = sin.readLine();
						Queries quer = new Queries();
						quer.getBDayByYear(annee);
					} else if(recherche.equals("Prenom")) {
						sout.println("Entrez un prénom ");
						String prenom = sin.readLine();
						Queries quer = new Queries();
						quer.prenom(prenom);
					} else if(recherche.equals("Quit")) {
						sout.println("Retour au menu précédent");
						break;
					} else {
						sout.println("Retry !");
						sout.println("AvAnnee ApAnnee Annee Prenom");
					}
				}
				else if(message.equals("Quit")){
					sout.println("QuitOK");
					m_socket.close();
					break;
				} else {
					sout.println("Retry !");
					System.out.println("Le client a écrit une commande inexistante");
				}
			}
		} catch (Exception e) {}
	}
	
}
