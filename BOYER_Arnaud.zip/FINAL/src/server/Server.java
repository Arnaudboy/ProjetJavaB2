package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	
	public Server() {
		try {
			ServerSocket ss = new ServerSocket(1234);
			while(true) {
				System.out.println("Server à l'écoute ...");
				Socket socket = ss.accept();
				ThreadConnexionClient tcc = new ThreadConnexionClient(socket, this);
				new Thread(tcc).start();
			}
		} catch (IOException e) {
			System.err.println(e);
		}
	}

	public static void main(String[] args) {
		new Server();
	}

}
