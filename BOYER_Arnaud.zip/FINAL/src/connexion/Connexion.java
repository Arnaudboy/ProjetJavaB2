package connexion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Connexion {
	private Statement m_state;
	public Connexion() {
		String url = "jdbc:mysql://localhost/birthday";
		try {
			Connection con = DriverManager.getConnection(url, "arnaud", "arnaud22");
			m_state = con.createStatement();
		} catch (SQLException e) {
			System.err.println(e);
		}
	}

	public ResultSet resultat(String query) {
		try {
			return m_state.executeQuery(query);
		} catch (Exception e) {
			System.err.println(e);
		}
		return null;
	}
}
