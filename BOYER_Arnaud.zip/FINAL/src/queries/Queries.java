package queries;

import java.sql.ResultSet;
import java.sql.SQLException;

import connexion.Connexion;

public class Queries {
	private Connexion m_con = new Connexion();
	
	public String tout() {
		ResultSet resultatRequete =  m_con.resultat("select * from birthday");
		try {
			if (!resultatRequete.isBeforeFirst() ) {    
			    return "No data"; 
			} else {
				return s(resultatRequete);
			}
		} catch (SQLException e) {
			System.err.println(e);
		}
		return null;
	}
	
	public String getBDayByYear(String year) {
		ResultSet resultatRequete =  m_con.resultat("select * from birthday where DATE_FORMAT(date, '%Y')="+year);
		try {
			if (!resultatRequete.isBeforeFirst() ) {    
			    return "No data"; 
			} else {
				return s(resultatRequete);
			}
		} catch (SQLException e) {
			System.err.println(e);
		}
		return null;
	}
	
	public String AvAnnee(String year) {
		ResultSet resultatRequete =  m_con.resultat("select * from birthday where DATE_FORMAT(date, '%Y')<"+year);
		try {
			if (!resultatRequete.isBeforeFirst() ) {    
			    return "No data"; 
			} else {
				return s(resultatRequete);
			}
		} catch (SQLException e) {
			System.err.println(e);
		}
		return null;
	}
	
	public String ApAnnee(String year) {
		ResultSet resultatRequete =  m_con.resultat("select * from birthday where DATE_FORMAT(date, '%Y')>"+year);
		try {
			if (!resultatRequete.isBeforeFirst() ) {    
			    return "No data"; 
			} else {
				return s(resultatRequete);
			}
		} catch (SQLException e) {
			System.err.println(e);
		}
		return null;
	}
	
	public String prenom(String prenom) {
		ResultSet resultatRequete =  m_con.resultat("select * from birthday where prenom="+prenom);
		try {
			if (!resultatRequete.isBeforeFirst() ) {    
			    return "No data"; 
			} else {
				return s(resultatRequete);
			}
		} catch (SQLException e) {
			System.err.println(e);
		}
		return null;
	}
	
	private String s(ResultSet resreq) {
		String res = "";
		try {
			while (resreq.next()) {
				String prenom = resreq.getString("prenom");
				String nom = resreq.getString("nom");
				String date = resreq.getString("date");
				res = res + String.format("%s %s né(e) le : %s\n", prenom, nom, date);
			}
			return res;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public static void main(String[] args) {
		Queries queries = new Queries();
		//queries.getBDayByYear("198");
	}

}
